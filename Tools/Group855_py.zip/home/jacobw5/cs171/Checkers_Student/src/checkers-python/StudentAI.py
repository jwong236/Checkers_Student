from random import randint
from BoardClasses import Move
from BoardClasses import Board
import math
from copy import deepcopy

import logging

# Basic configuration of the logging system
logging.basicConfig(level=logging.DEBUG, filename='myapp.log', filemode='w',
                    format='%(name)s - %(levelname)s - %(message)s')
#The following part should be completed by students.
#Students can modify anything except the class name and exisiting functions and varibles.
class StudentAI():

    class Node():
        def __init__(self, move, color, parent = None):
            self.move = move
            self.color = color
            self.wins = 0
            self.visit_count = 0
            self.children = []
            self.parent = parent
        
        def calculate_winrate(self):
            if self.visit_count == 0:
                return 0
            return self.wins / self.visit_count

        def calculate_ucb(self, exploration_param=math.sqrt(2)):
            if self.visit_count == 0:
                return float('inf')

            ucb = self.calculate_winrate() + exploration_param * math.sqrt(math.log(self.parent.visit_count) / self.visit_count)
            return ucb


    def __init__(self,col,row,p):
        self.col = col
        self.row = row
        self.p = p
        self.board = Board(col,row,p)
        self.board.initialize_game()
        self.color = ''
        self.opponent = {1:2,2:1}
        self.color = 2

        # continuous tree initialization
        self.root = self.Node(None, 1)


    def get_move(self,move):
        if len(move) != 0:
            self.board.make_move(move,self.opponent[self.color])
            # update root to move
            for node in self.root.children:
                if str(node.move) == str(move):
                    self.root = node
                    self.root.parent.children = None
                    self.root.parent = None
                    break

        else:
            self.color = 1

             # continuous tree initialization
            self.root = self.Node(None, 2)
            

        # logging.info(self.root)
        # logging.info(self.root.color)
        # for child in self.root.children:
        #     logging.info(child.color)

        move = self.mcts(300)
        self.board.make_move(move,self.color)
        # update root to move
        for node in self.root.children:
            if str(node.move) == str(move):
                self.root = node
                self.root.parent.children = None
                self.root.parent = None
                break

        return move


    def mcts(self, iterations):
        self.root = self.Node(None, self.opponent[self.color])
        moves = self.board.get_all_possible_moves(self.color)
        if self.root.children == []:
            moves = self.board.get_all_possible_moves(self.color)
            for piece in moves:
                for move in piece:
                    self.root.children.append(self.Node(move, self.color, self.root))
        
        for _ in range(iterations):
            self.board_copy = deepcopy(self.board)

            selected_node = self.selection(self.root)

            expanded_node = self.expansion(selected_node)

            outcome = self.simulation(self.opponent[expanded_node.color])

            self.propagate_back(expanded_node, outcome)
        return self.best_move(self.root.children)
    

    def selection(self, current_node):
        while current_node.children:
            best_node = None
            # best_ucb_value = float('-inf')
            # for child in current_node.children:
            #     ucb_value = child.calculate_ucb()

            #     if ucb_value > best_ucb_value:
            #         best_ucb_value = ucb_value
            #         best_node = child
            

            #if current_node.color == self.opponent[self.color]:
            best_ucb_value = float('-inf')
            for child in current_node.children:
                ucb_value = child.calculate_ucb()

                if ucb_value > best_ucb_value:
                    best_ucb_value = ucb_value
                    best_node = child
            """else:
                best_ucb_value = float('inf')
                for child in current_node.children:
                    ucb_value = child.calculate_ucb()

                    if ucb_value <= best_ucb_value:
                        best_ucb_value = ucb_value
                        best_node = child
            """
            current_node = best_node

            # logging.info(current_node.color)
            # logging.info(current_node.move)

            self.board_copy.make_move(current_node.move, current_node.color)
            # logging.info("end")

        return current_node


    def expansion(self, current_node):
        moves = self.board_copy.get_all_possible_moves(self.opponent[current_node.color])
        if not moves: return current_node

        for piece in moves:
            for move in piece:
                current_node.children.append(self.Node(move, self.opponent[current_node.color], current_node))
        
        index = randint(0, len(current_node.children)-1)
        next_move = current_node.children[index]

        # logging.info("test")
        # logging.info(moves)
        # logging.info(current_node.move)
        # logging.info(next_move.move)

        self.board_copy.make_move(next_move.move, next_move.color)
        
        return next_move


    def simulation(self, current_color):
        while self.board_copy.is_win(current_color) == 0:
            moves = self.board_copy.get_all_possible_moves(current_color)
            if not moves:
                break

            index = randint(0, len(moves)-1)
            inner_index = randint(0, len(moves[index])-1)

            move = moves[index][inner_index]
            self.board_copy.make_move(move, current_color)

            current_color = self.opponent[current_color]
        else:
            return self.board_copy.is_win(current_color)
        return -1


    def propagate_back(self, current_node, outcome):
        # logging.info(outcome)
        while current_node != None:
            current_node.visit_count += 1
            if outcome != -1:
                if (current_node.color == self.opponent[outcome]):
                    current_node.wins += 1
            # else:
            #     if current_node.color == self.color:
            #         current_node.wins += 1
            # elif outcome == -1: 
            #     current_node.wins += 0.5
            current_node = current_node.parent


    def best_move(self, moves):
        best_ucb_value = float('-inf')
        best_node = None

        # logging.info("best moves")
        for move in moves:
            #logging.info(move.wins)
            # logging.info(move.visit_count)
            ucb_value = move.calculate_winrate() - math.sqrt(2) * math.sqrt(math.log(move.parent.visit_count) / move.visit_count)

            if ucb_value > best_ucb_value:
                best_ucb_value = ucb_value
                best_node = move

        return best_node.move


